config_path="/storage/emulated/0/Android/Ls/writeback"
scene_config_file_0="/data/swap_config.conf"
scene_config_file_1="/data/adb/swap_controller/swap.conf"

miui_version=$(getprop "ro.miui.ui.version.code")

[[ "$miui_version" -lt 13 ]] && echo "- MIUI版本过低" && exit

echo "
- 配置文件位于 $config_path
- 可在配置文件内设置内存扩展大小
- 更改配置后需要手动执行一个脚本（难受啊）
- 需要开启系统的内存扩展
"

extm_size=$(awk -F '内存扩展大小=' '/内存扩展大小=/{print $2}' "$config_path/writeback.conf")

[[ ! -e "$config_path/writeback.conf" ]] && mkdir -p "$config_path" && touch $config_path/writeback.conf
[[ ! -e "$config_path/更新配置（以root权限执行）.sh" ]] && mkdir -p "$config_path" && touch "$config_path/更新配置（以root权限执行）.sh"&& cp $MODPATH/updataconfig.sh $config_path/更新配置（以root权限执行）.sh

extm_size="${extm_size:-4096}"

echo "##### 内存扩展配置 #####
# 设置内存扩展大小，单位 MB
# 建议 3072或4096
# 更改后手动执行更新配置

内存扩展大小=$extm_size

##### 内存进化配置 #####
# 不用配置
" > $config_path/writeback.conf

setprop persist.miui.extm.bdsize "$extm_size"

if [[ -e "$scene_config_file_1" ]] || [[ -e "$scene_config_file_0" ]]; then
    echo "- 修改scene附加模块配置中"
    sed -i 's/zram_writeback=false/zram_writeback=true/g' $scene_config_file_1
    sed -i 's/zram_writeback=false/zram_writeback=default/g' $scene_config_file_0
    sed -i 's/zram_writeback=true/zram_writeback=default/g' $scene_config_file_0
fi

set_perm_recursive $MODPATH 0 0 0755 0644
set_perm $MODPATH/system/bin/writeback 0 0 0777

echo "
- 当前配置详情：
  内存扩展大小=$extm_size
"
