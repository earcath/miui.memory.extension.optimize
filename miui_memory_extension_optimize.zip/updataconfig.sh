config_path="/storage/emulated/0/Android/Ls/writeback"

extm_size=$(awk -F '内存扩展大小=' '/内存扩展大小=/{print $2}' "$config_path/writeback.conf")

setprop persist.miui.extm.bdsize "$extm_size"
