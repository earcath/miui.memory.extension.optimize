#!/system/bin/sh
export PATH="/system/bin:/system/xbin:/vendor/bin:/system/system_ext/bin:$(magisk --path)/.magisk/busybox:$PATH"
MODDIR=${0%/*}

log_file="/cache/writeback.log"
scene_config_file_0="/data/swap_config.conf"
scene_config_file_1="/data/adb/swap_controller/swap.conf"
config_path="/storage/emulated/0/Android/Ls/writeback"

> "$log_file"

extm_size=$(awk -F '内存扩展大小=' '/内存扩展大小=/{print $2}' "$config_path/writeback.conf")

log() {
    printf "[%s] %s\n" "$(date "+%Y-%m-%d %H:%M:%S")" "$1" >> "$log_file"
}

set_value() {
  if [[ -f $2 ]]; then
    chmod 644 $2 2>/dev/null
    echo $1 > $2
  fi
}

backing_dev=$(cat /sys/block/zram0/backing_dev)

set_value "$backing_dev" /sys/block/zram0/backing_dev
set_value 0 /sys/block/zram0/writeback_limit_enable

# 获取persist.miui.extm.enable的值
enable=$(getprop persist.miui.extm.enable)
log "内存扩展状态: $enable"

# 获取persist.miui.extm.bdsize的值
bdsize=$(getprop persist.miui.extm.bdsize)
log "内存扩展大小: $bdsize"

if [[ -e "$scene_config_file_1" ]] || [[ -e "$scene_config_file_0" ]]; then
    echo "- 修改scene附加模块配置中"
    sed -i 's/zram_writeback=false/zram_writeback=true/g' $scene_config_file_1
    sed -i 's/zram_writeback=false/zram_writeback=default/g' $scene_config_file_0
    sed -i 's/zram_writeback=true/zram_writeback=default/g' $scene_config_file_0
fi

if [[ "$enable" = "1" ]]; then
    if [[ -e "$scene_config_file_1" ]]; then
        scene_zram_writeback=$(awk -F 'zram_writeback=' '/zram_writeback=/{print $2}' "$scene_config_file_1")
    elif [[ -e "$scene_config_file_0" ]]; then
        scene_zram_writeback=$(awk -F 'zram_writeback=' '/zram_writeback=/{print $2}' "$scene_config_file_0")
    fi

    if [[ "$scene_zram_writeback" != "false" ]]; then
        writeback
    else
        log "writeback被禁止，请检查scene附加模块"
    fi
else
    log "未启用内存扩展，模块停止运行"
fi
